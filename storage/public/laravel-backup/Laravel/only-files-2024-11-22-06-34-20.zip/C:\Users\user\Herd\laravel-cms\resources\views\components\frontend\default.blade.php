<x-frontend.header />
<main>
    {!! $content !!}
</main>
<x-frontend.footer />
