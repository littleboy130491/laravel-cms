<div wire:poll.<?php echo e($this->interval()); ?>>
	<?php echo e($this->table); ?>

</div>
<?php /**PATH C:\Users\user\Herd\laravel-cms\vendor\shuvroroy\filament-spatie-laravel-backup\src\/../resources/views/components/backup-destination-list-records.blade.php ENDPATH**/ ?>