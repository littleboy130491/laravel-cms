<x-partials.header/>
<main>
    {!! $content !!}
</main>
<x-partials.footer/>