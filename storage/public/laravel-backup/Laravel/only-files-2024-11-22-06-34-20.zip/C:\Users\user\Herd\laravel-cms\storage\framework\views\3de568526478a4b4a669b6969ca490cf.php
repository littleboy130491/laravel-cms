<?php
    $hasInlineLabel = $hasInlineLabel();
    $isConcealed = $isConcealed();
    $isDisabled = $isDisabled();
    $rows = $getRows();
    $shouldAutosize = $shouldAutosize();
    $statePath = $getStatePath();
    $aceUrl = $getUrl();
    $config = $getConfig();
    $enabledExtensions = $getEnabledExtensions();
    $editorOptions = $getEditorOptions();
?>

<?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => $getFieldWrapperView()] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['field' => $field]); ?>
     <?php $__env->slot('label', null, ['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Arr::toCssClasses([
        'sm:pt-1.5' => $hasInlineLabel,
    ]))]); ?> 
        <?php echo e($getLabel()); ?>

     <?php $__env->endSlot(); ?>
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'ace-editor-wrapper',
        'focus-within:ring-0' => $isDisabled,
        'base' => !$errors->has($statePath),
        'danger' => $errors->has($statePath),
    ]); ?>">
        <div wire:ignore x-ignore ax-load
            ax-load-src="<?php echo e(\Filament\Support\Facades\FilamentAsset::getAlpineComponentSrc('filament-ace-editor', 'riodwanto/filament-ace-editor')); ?>"
            x-data="aceEditorComponent({
                state: $wire.<?php echo e($applyStateBindingModifiers("entangle('{$statePath}')", isOptimisticallyLive: false)); ?>,
                statePath: '<?php echo e($statePath); ?>',
                placeholder: <?php echo \Illuminate\Support\Js::from($getPlaceholder() ?? '')->toHtml() ?>,
                aceUrl: '<?php echo e($aceUrl); ?>',
                extensions: <?php echo \Illuminate\Support\Js::from($enabledExtensions)->toHtml() ?>,
                config: <?php echo \Illuminate\Support\Js::from($config)->toHtml() ?>,
                options: <?php echo \Illuminate\Support\Js::from($editorOptions)->toHtml() ?>,
                darkTheme: <?php echo \Illuminate\Support\Js::from($getDarkTheme())->toHtml() ?>,
                disableDarkTheme: <?php echo \Illuminate\Support\Js::from($isDisableDarkTheme())->toHtml() ?>,
            })" x-ref="aceCodeEditor" style="min-height: <?php echo e($getHeight()); ?>;" class="ace-editor"></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php /**PATH C:\Users\user\Herd\laravel-cms\resources\views/vendor/filament-ace-editor/components/filament-ace-editor.blade.php ENDPATH**/ ?>