<x-frontend.header/>
<main>
    {!!$content!!}
</main>
<main>
    This is sidebar
</main>
<x-frontend.footer/>
