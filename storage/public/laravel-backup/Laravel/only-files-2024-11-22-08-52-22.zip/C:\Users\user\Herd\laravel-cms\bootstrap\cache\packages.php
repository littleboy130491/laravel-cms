<?php return array (
  'anourvalar/eloquent-serialize' => 
  array (
    'aliases' => 
    array (
      'EloquentSerialize' => 'AnourValar\\EloquentSerialize\\Facades\\EloquentSerializeFacade',
    ),
  ),
  'awcodes/filament-curator' => 
  array (
    'providers' => 
    array (
      0 => 'Awcodes\\Curator\\CuratorServiceProvider',
    ),
  ),
  'bezhansalleh/filament-shield' => 
  array (
    'providers' => 
    array (
      0 => 'BezhanSalleh\\FilamentShield\\FilamentShieldServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentShield' => 'BezhanSalleh\\FilamentShield\\Facades\\FilamentShield',
    ),
  ),
  'blade-ui-kit/blade-heroicons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Heroicons\\BladeHeroiconsServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
    ),
  ),
  'blendbyte/filament-title-with-slug' => 
  array (
    'providers' => 
    array (
      0 => 'Camya\\Filament\\FilamentTitleWithSlugServiceProvider',
    ),
  ),
  'codewithdennis/filament-select-tree' => 
  array (
    'providers' => 
    array (
      0 => 'CodeWithDennis\\FilamentSelectTree\\FilamentSelectTreeServiceProvider',
    ),
  ),
  'filament/actions' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Actions\\ActionsServiceProvider',
    ),
  ),
  'filament/filament' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\FilamentServiceProvider',
    ),
  ),
  'filament/forms' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Forms\\FormsServiceProvider',
    ),
  ),
  'filament/infolists' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Infolists\\InfolistsServiceProvider',
    ),
  ),
  'filament/notifications' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Notifications\\NotificationsServiceProvider',
    ),
  ),
  'filament/spatie-laravel-settings-plugin' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\SpatieLaravelSettingsPluginServiceProvider',
    ),
  ),
  'filament/support' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Support\\SupportServiceProvider',
    ),
  ),
  'filament/tables' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Tables\\TablesServiceProvider',
    ),
  ),
  'filament/widgets' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Widgets\\WidgetsServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'jeffgreco13/filament-breezy' => 
  array (
    'providers' => 
    array (
      0 => 'Jeffgreco13\\FilamentBreezy\\FilamentBreezyServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentBreezy' => 'Jeffgreco13\\FilamentBreezy\\Facades\\FilamentBreezy',
    ),
  ),
  'kirschbaum-development/eloquent-power-joins' => 
  array (
    'providers' => 
    array (
      0 => 'Kirschbaum\\PowerJoins\\PowerJoinsServiceProvider',
    ),
  ),
  'laravel/pail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Pail\\PailServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'livewire/livewire' => 
  array (
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'pestphp/pest-plugin-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Pest\\Laravel\\PestServiceProvider',
    ),
  ),
  'ralphjsmit/laravel-filament-seo' => 
  array (
    'providers' => 
    array (
      0 => 'RalphJSmit\\Filament\\SEO\\FilamentSEOServiceProvider',
    ),
    'aliases' => 
    array (
    ),
  ),
  'ralphjsmit/laravel-helpers' => 
  array (
    'providers' => 
    array (
      0 => 'RalphJSmit\\Helpers\\HelpersServiceProvider',
    ),
    'aliases' => 
    array (
      'Helpers' => 'RalphJSmit\\Helpers\\Facades\\Helpers',
    ),
  ),
  'ralphjsmit/laravel-seo' => 
  array (
    'providers' => 
    array (
      0 => 'RalphJSmit\\Laravel\\SEO\\LaravelSEOServiceProvider',
    ),
    'aliases' => 
    array (
      'SEOManager' => 'RalphJSmit\\Laravel\\SEO\\Facades\\SEOManager',
    ),
  ),
  'riodwanto/filament-ace-editor' => 
  array (
    'providers' => 
    array (
      0 => 'Riodwanto\\FilamentAceEditor\\FilamentAceEditorServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentAceEditor' => 'Riodwanto\\FilamentAceEditor\\Facades\\FilamentAceEditor',
    ),
  ),
  'ryangjchandler/blade-capture-directive' => 
  array (
    'providers' => 
    array (
      0 => 'RyanChandler\\BladeCaptureDirective\\BladeCaptureDirectiveServiceProvider',
    ),
    'aliases' => 
    array (
      'BladeCaptureDirective' => 'RyanChandler\\BladeCaptureDirective\\Facades\\BladeCaptureDirective',
    ),
  ),
  'shuvroroy/filament-spatie-laravel-backup' => 
  array (
    'providers' => 
    array (
      0 => 'ShuvroRoy\\FilamentSpatieLaravelBackup\\FilamentSpatieLaravelBackupServiceProvider',
    ),
  ),
  'spatie/eloquent-sortable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\EloquentSortable\\EloquentSortableServiceProvider',
    ),
  ),
  'spatie/laravel-activitylog' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Activitylog\\ActivitylogServiceProvider',
    ),
  ),
  'spatie/laravel-backup' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Backup\\BackupServiceProvider',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'spatie/laravel-settings' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelSettings\\LaravelSettingsServiceProvider',
    ),
  ),
  'spatie/laravel-signal-aware-command' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\SignalAwareCommand\\SignalAwareCommandServiceProvider',
    ),
    'aliases' => 
    array (
      'Signal' => 'Spatie\\SignalAwareCommand\\Facades\\Signal',
    ),
  ),
  'spatie/laravel-sitemap' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Sitemap\\SitemapServiceProvider',
    ),
  ),
  'z3d0x/filament-logger' => 
  array (
    'providers' => 
    array (
      0 => 'Z3d0X\\FilamentLogger\\FilamentLoggerServiceProvider',
    ),
    'aliases' => 
    array (
      'FilamentLogger' => 'Z3d0X\\FilamentLogger\\Facades\\FilamentLogger',
    ),
  ),
);